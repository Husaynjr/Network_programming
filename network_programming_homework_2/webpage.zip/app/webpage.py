from flask import Flask, render_template, url_for, request, jsonify
import tensorflow as tf
import numpy as np
from PIL import Image
app = Flask(__name__)
model = tf.keras.models.load_model("static/catordog.h5")
classes = ['cat', 'dog']

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/about')
def about():
    return render_template("about.html")

@app.route('/conatcts')
def contacts():
    return render_template("contacts.html")

@app.route('/upload', methods = ['POST', 'GET'])
def predict():
    if request.method == 'GET':
        return render_template("predict.html")
    else:
        file = request.files['file']
        image = Image.open(file)
        resized_image = image.resize((256,256))
        image = np.array(resized_image)
        image = image.astype('float32')/255.0
        image = np.expand_dims(image, axis=0)
        
        prediction = model.predict(image)
        if prediction < 0.5:
            predicted_class = "\U0001F431"
        else :
            predicted_class = "\U0001F436"
        print("predict = ",predicted_class)
        return render_template("result.html",result=predicted_class)
    

if __name__ == "__main__":
    app.run(debug= True, host ="0.0.0.0", port=5000)